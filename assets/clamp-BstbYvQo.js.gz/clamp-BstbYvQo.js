function m(I,N=Number.NEGATIVE_INFINITY,a=Number.POSITIVE_INFINITY){return Math.min(a,Math.max(N,I))}export{m as c};
