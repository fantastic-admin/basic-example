import{_ as o}from"./index.vue_vue_type_script_setup_true_lang-B25PrVz1.js";import"./logo-A4CMGNjt.js";import"./index-Dkrni94Y.js";export{o as default};
