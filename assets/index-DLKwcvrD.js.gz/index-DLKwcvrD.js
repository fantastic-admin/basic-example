import{_ as o}from"./index.vue_vue_type_script_setup_true_lang-D2sTVCPX.js";import"./logo-W9uVms6l.js";import"./index-B6Nq-W-n.js";export{o as default};
