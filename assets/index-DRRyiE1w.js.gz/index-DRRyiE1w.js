import{_ as o}from"./index.vue_vue_type_script_setup_true_lang-sKiHHHV7.js";import"./index-B6Nq-W-n.js";import"./useMainPage-CbIMt0U5.js";export{o as default};
