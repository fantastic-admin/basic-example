import{_ as o}from"./index.vue_vue_type_script_setup_true_lang-CRqgKyIK.js";import"./logo-A4CMGNjt.js";import"./index-Xdtw-1bo.js";export{o as default};
