import{_ as o}from"./index.vue_vue_type_script_setup_true_lang-BBp86Bmd.js";import"./logo-A4CMGNjt.js";import"./index-DjzHQJ1v.js";export{o as default};
