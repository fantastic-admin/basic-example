import{_ as m}from"./inputnumber.vue_vue_type_script_setup_true_lang-yUfYuM_s.js";import"./index-DbcIveVp.js";export{m as default};
