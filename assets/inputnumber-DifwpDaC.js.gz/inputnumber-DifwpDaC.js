import{_ as m}from"./inputnumber.vue_vue_type_script_setup_true_lang-0taKGAo_.js";import"./index-DArrwvlJ.js";export{m as default};
