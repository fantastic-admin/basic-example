import{H as r,aN as t,aO as a}from"./index-BSY0Q56E.js";function n(o){return r(()=>{var e;return t(o)?!!((e=a(o))!=null&&e.closest("form")):!0})}export{n as u};
