import{H as r,aJ as t,aK as a}from"./index-DArrwvlJ.js";function n(o){return r(()=>{var e;return t(o)?!!((e=a(o))!=null&&e.closest("form")):!0})}export{n as u};
