import{H as r,aK as t,aL as a}from"./index-DjzHQJ1v.js";function n(o){return r(()=>{var e;return t(o)?!!((e=a(o))!=null&&e.closest("form")):!0})}export{n as u};
