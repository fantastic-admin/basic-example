import{J as r,aM as t,aN as a}from"./index-BiXmQh6r.js";function n(o){return r(()=>{var e;return t(o)?!!((e=a(o))!=null&&e.closest("form")):!0})}export{n as u};
