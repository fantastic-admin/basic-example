import{J as r,ap as t,aM as a}from"./index-D5MCxcUQ.js";function n(o){return r(()=>{var e;return t(o)?!!((e=a(o))!=null&&e.closest("form")):!0})}export{n as u};
