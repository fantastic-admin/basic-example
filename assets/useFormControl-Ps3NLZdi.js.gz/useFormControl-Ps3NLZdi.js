import{J as r,aq as t,aM as a}from"./index-CJB5jCfL.js";function n(o){return r(()=>{var e;return t(o)?!!((e=a(o))!=null&&e.closest("form")):!0})}export{n as u};
