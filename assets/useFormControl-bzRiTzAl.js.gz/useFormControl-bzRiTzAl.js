import{J as r,aM as t,aN as a}from"./index-DXZKKOp8.js";function n(o){return r(()=>{var e;return t(o)?!!((e=a(o))!=null&&e.closest("form")):!0})}export{n as u};
