import{s as r}from"./index-Ruu4zcVF.js";function n(){const e=r();function o(){e.push({name:"reload"})}return{reload:o}}export{n as u};
