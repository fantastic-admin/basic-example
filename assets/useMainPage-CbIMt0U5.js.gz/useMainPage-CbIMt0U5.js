import{s as r}from"./index-B6Nq-W-n.js";function n(){const e=r();function o(){e.push({name:"reload"})}return{reload:o}}export{n as u};
