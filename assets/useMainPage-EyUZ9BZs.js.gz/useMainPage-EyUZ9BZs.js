import{p as r}from"./index-BB8nNV-H.js";function n(){const e=r();function o(){e.push({name:"reload"})}return{reload:o}}export{n as u};
