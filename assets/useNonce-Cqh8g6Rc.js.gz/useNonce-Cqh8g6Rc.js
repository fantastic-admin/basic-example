import{bC as r,e as u,J as a}from"./index-CJB5jCfL.js";function i(e){const o=r({nonce:u()});return a(()=>{var t;return(e==null?void 0:e.value)||((t=o.nonce)==null?void 0:t.value)})}export{i as u};
